a=imread('rose.png');
imshow(a);
imtool(a)
impixelinfo;
imwrite(a,'new.bmp');
